import { Component, OnInit } from "@angular/core";
// import { DemoFilePickerAdapter } from "../demo-file-picker.adapter";
import { HttpClient } from "@angular/common/http";
@Component({
  selector: "progress",
  templateUrl: "./progress.component.html",
  styleUrls: ["./progress.component.css"]
})
export class SimpleDemoComponent implements OnInit {
  // public adapter = new DemoFilePickerAdapter(this.http);

  constructor(private http: HttpClient) {}

  public ngOnInit(): void {}

  public uploadSuccess(event: any): void {
    console.log(event);
  }
}
